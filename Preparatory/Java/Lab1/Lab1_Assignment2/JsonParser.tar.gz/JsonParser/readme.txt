Provide a json file from command line.
