print "Enter first name: "
x = raw_input()
print "Enter last name: "
y = raw_input()
print "Full name: " + x + " " + y

