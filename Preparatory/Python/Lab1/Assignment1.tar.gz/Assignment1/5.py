print "Enter Side A: "
x = int(raw_input())
print "Enter Side B: "
y = int(raw_input())
z = x*x + y*y
print "Hypotenuse: " + str(z)
