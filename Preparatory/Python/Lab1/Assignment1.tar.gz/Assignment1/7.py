a=10
print "Type of a: " + str(type(a))
b=4
print "Type of b: " + str(type(b))
c=3.4
print "Type of c: " + str(type(c))
d=a/10
print "Type of d: " + str(type(d))
e=b*c
print "Type of e: " + str(type(e))
a=a*e
print "Type of a: " + str(type(a))
s="IIITB"
print "Type of s: " + str(type(s))
t=a+s
print "Type of t: " + str(type(t))

