x=5
y=4
sum=x+y
print sum
