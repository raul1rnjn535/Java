movie = 990.0
busPopcorn = 290.0
meal = 1100.0
avg = (movie+busPopcorn+meal)/3
#print movie
#print busPopcorn
#print meal
print "Abhiraj= " + str(avg - movie)
print "Leon= " + str(avg-busPopcorn)
print "Vigyan= " + str(avg-meal)

