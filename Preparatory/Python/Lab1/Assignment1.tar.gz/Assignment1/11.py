print "Enter your study year(1,2..5): "
x = int(raw_input())
if x==1:
   print "You're courses are-\nCourse101\nCourse102\nCourse103\nCourse104\nCourse105"
elif x==2:
   print "You're courses are-\nCourse201\nCourse202\nCourse203\nCourse204\nCourse205"
elif x==3:
   print "You're courses are-\nCourse301\nCourse302\nCourse303\nCourse304\nCourse305"
elif x==4:
   print "You're courses are-\nCourse401\nCourse402\nCourse403\nCourse404\nCourse405"
elif x==5:
   print "You're courses are-\nCourse501\nCourse502\nCourse503\nCourse504\nCourse505"
else:
   print "You're course is over. Go get a job!!!"
