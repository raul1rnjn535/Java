x = int(raw_input())
if x < 18:
   print "You are a child! Suggestions for you are:\nNoddy\nNancy Drew\nPanchatantra\nAmar Chitra Katha\nTintin\nAsterix"
else:
   print "You are an adult! Suggestions for you are:\nThe Kite Runner\nThe Alchemist\nThe Zahir\nA Thousand Splendid Sons\nSacred Games"
