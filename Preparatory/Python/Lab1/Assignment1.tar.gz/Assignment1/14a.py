x=int(raw_input())
if x>-1 and x<18:
    print "child"
elif x>17:
    print "adult"
else:
    print "Invalid input!!!"
