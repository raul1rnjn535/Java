x=raw_input()
if x == 'y':
    print "You said 'yes' \n Hello World!"
else:
    print "Hello World!"
