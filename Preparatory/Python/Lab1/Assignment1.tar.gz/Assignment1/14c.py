a=int(raw_input())
count=0
while(count<a):
    print "Hello World!"
    count+=1

